# PLP_directRNA_design
Package used to create padlock probes that target RNA directly. It can be used for any gene and species.
